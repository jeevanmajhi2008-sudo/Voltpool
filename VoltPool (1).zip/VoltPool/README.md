# VoltPool

Peer-to-peer EV charging for India. Drivers book chargers at homes, shops and offices nearby, and hosts earn from chargers that would otherwise sit idle. A charging van comes to you when there is no charger around.

Built by Xerxes for Unstop's Build Your MVP challenge, 2026.

## What's in this folder

| File | What it is |
|---|---|
| `index.html` | The full VoltPool app, with both the Drive and Host sides. Double-click to open it in any browser. |
| `blueprint.html` | Product blueprint: pros and cons, tech stack, architecture, data model and 14-day plan. |
| `photos/` | The original charger photos used in the listings. They are also built into `index.html`. |

## Live version

https://claude.ai/artifact/T4oquzYwkgpwkA6hc5uzZZ

The live link adds three things that a downloaded file can't do:
- live sync between devices
- photo uploads saved to shared listings
- the AI help chat

Opened from this folder, `index.html` runs in offline mode, with sample data saved in that browser.

## Features

- **Drive side:** find a charger by speed (Fast DC, Standard AC, Slow) and vehicle (car, scooty, e-auto, cargo van); book or make a price offer; Charge now matching; a PIN to start each session; pay only for the kWh delivered, by wallet or UPI; ratings and reviews
- **Van & services:** emergency rescue (₹199 call-out) and doorstep top-up (₹99), with an advance at booking. Add-on services include tyre pressure, washer water, waterless wash, puncture repair, EV health check and minor repairs
- **VoltPool Premium (₹299 a month):** free tyre and water checks, 50% off call-outs, priority dispatch, 15% off services, and members-only services
- **Host side:** listings with 8 labelled photo slots; time-of-day pricing (morning +15%, day −5%, evening +15%, night +25%) plus demand pricing; accept, decline or counter offers; earnings dashboard
- **Platform:** revenue overview and a support ticket inbox
- **Help chat:** an assistant answers first, and "Talk to a person" opens a support ticket
- **About page:** how it works, pricing, safety, revenue model and FAQs
